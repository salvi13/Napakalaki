# To change this license header, choose License Headers in Project Properties.
# To change this template file, choose Tools | Templates
# and open the template in the editor.

class Card
  def initialize
    
  def get_basic_value
    raise NotImplementedError.new
  end

  def get_special_value
    raise NotImplementedError.new
  end
  
  end
end

  
