#encoding: utf-8

module TreasureKind
    ARMOR = "ARMOR"
    ONEHAND = "ONEHAND"
    BOTHHAND = "BOTHHAND"
    HELMET = "HELMET"
    SHOE = "SHOE"
    NECKLACE = "NECKLACE"
end
